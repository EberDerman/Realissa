<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Servicios</h2>

        <p>
            Crowdfunding Inmobiliario. CRECER Y GANAR EN EQUIPO
            Se trata de un modelo de financiación colectiva donde la inversión se consolida a través de la cooperación de varios inversores con el fin de comprar y/o construir propiedades.
            En esta modalidad, el retorno de inversión y la rentabilidad del proyecto, se producirán al momento de la venta de la propiedad y se distribuirá proporcionalmente acorde al aporte cada inversor.
            /INVERSIÓN
            /COMPRA DE LOTE + CONSTRUCCIÓN+ VENTA
            /INVERSIÓN + GANANCIA

        </p>
    </div>



</div>

