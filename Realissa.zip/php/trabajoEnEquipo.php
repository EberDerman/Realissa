<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Nuestra palabra y el trabajo en equipo:</h2>
        <h4>Nuestros grandes activos</h4>
        <p>
            Nos comprometemos a cuidar tu capital e invertirlo en los mejores negocios de Real Estate
            disponibles al momento de tomar la decisión, buscando siempre que sean lo más seguros y rentables.
            Contáctanos para conocer en primera persona nuestra trayectoria y todos los proyectos que llevamos adelante.
            Agenda una reunión con nuestros asesores para comprobarlo.

        </p>
    </div>



</div>