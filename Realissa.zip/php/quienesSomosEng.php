<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Who We Are</h2>

        <p>
            A <strong>experienced multidisciplinary team</strong> dedicated to advising and supporting you from the first meeting in every real estate and property investment you make in the United States.
        </p>

    </div>


</div>