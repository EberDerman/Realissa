<style>
     .numero{
        font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
    }
</style>


<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Diferenciales</h2>

        <p>
            Top <span class="numero">5</span> de mercado inmobiliarios de USA
            Precio medio de mercado USD <span class="numero">446.350</span>
            Tiempo de venta promedio <span class="numero">30</span> días.
            La demanda de vivienda supera la oferta
            Cape Coral también conocido como la "Venecia americana", ya que cuenta con <span class="numero">640</span> km de canales
            navegables; algunos de los cuales tienen acceso al golfo de México.
            Según la Oficina de Investigación Económica de Florida, en proyecciones de crecimiento de la población a <span class="numero">30</span> años, el Condado de Lee (Cape Coral) crecerá un <span class="numero">58.8</span>% hasta <span class="numero">2045</span>.
            Confirmando así el mayor crecimiento de un condado en Florida.
        </p>
    </div>



</div>