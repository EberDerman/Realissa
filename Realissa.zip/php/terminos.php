<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">


        <h2 class="mb-4">TÉRMINOS PARA FAMILIARIZARTE CON LOS NEGOCIOS EN USA</h2>













        <h4>EIN</h4>
        <p>Es un Número de Identificación del Empleador, el cual es exclusivo para entidades comerciales que operan en los Estados Unidos.</p>

        <h4>INSURANCE</h4>
        <p>Tiene por objeto cubrir los daños que se produzcan en una vivienda y/o mobiliario y que se deriven de cualquier imprevisto.</p>

        <h4>DUE DILIGENCE</h4>
        <p>La debida diligencia es la investigación y auditoria tanto sobre el título como estado de la tierra que se realiza antes de celebrar un acuerdo o contrato para el posterior desarrollo de la vivienda.</p>

        <h4>CLOSING COSTS</h4>
        <p>Cuando se vende una casa, hay un momento en la transacción conocido como el cierre, cuando el título de propiedad es transferido al nuevo dueño.</p>

        <h4>SURVEY</h4>
        <p>Es una ficha que proporciona información relativa al estado del (mensura, amojonamiento, etc.), y que es necesario conocer en una operación de compra-venta inmobiliaria para minimizar los posibles riesgos asumibles por el comprador.</p>

        <h4>UNDERAIR</h4>
        <p>Es el área construida que se encuentra refrigerada o calefaccionada, queda excluido de este concepto el sector de garaje, la galería y el hall de ingreso exterior si lo tuviere.</p>

        <h4>LLC: Limited Liability Company</h4>
        <p>Una LLC es una compañía de responsabilidad limitada en EE.UU. que ayuda a los emprendedores a separar sus responsabilidades personales de las responsabilidades comerciales.</p>
    </div>