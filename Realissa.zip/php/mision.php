<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Visiones con nombre y apellido</h2>


        <p>
            En Realissa, guiamos la inversión de nuestros clientes-socios de
            acuerdo al perfil que cada uno tenga, porque entendemos que
            cada uno de ellos representan una oportunidad de crecimiento para
            todos y son el pilar sobre el cual construimos nues
        </p>
    </div>



</div>