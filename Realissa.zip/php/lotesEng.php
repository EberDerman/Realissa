<div class="container mt-5">


<div class="col-md-7 mb-4 textoComponentes">
    <h2 class="mb-4">Lot Search and Evaluation</h2>

    <p>
    <h4>Quality Processes and Expert Construction Professionals.</h4>
    <li>Lot Reservation and Due Diligence</li>
    <li>Supervision and Information</li>
    <li>Permits and Approvals</li>
    <li>Construction</li>
    <li>Decision</li>
    <li>Property Sale</li>
    </p>
</div>



</div>