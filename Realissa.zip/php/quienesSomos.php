<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">¿Quienes somos?</h2>

        <p>
            Un <strong>experimentado equipo multidisciplinario</strong> dedicado a asesorar y acompañarte desde el primer
            encuentro en cada inversión de bienes raíces y Real Estate que realices en Estados Unidos.
           
        </p>
    </div>


</div>