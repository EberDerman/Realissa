<div class="container mt-5">
    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">¿Qué hacemos?</h2>
        <p> <strong>Acompañamos, asesoramos e instruimos</strong> a nuestros clientes y socios estratégicos para que puedan canalizar sus inversiones inmobiliarias de manera individual, colectiva (de manera grupal) o a través del peer-to-peer funding inmobiliario (microinversiones de varios socios estratégicos), administrando, supervisando y ejecutando cada etapa del proyecto, siempre. </p>
    </div>
</div>