<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">What We Do</h2>

        <p>
            <strong>We accompany, advise, and guide</strong> our clients and strategic partners to channel their real estate investments individually, collectively (group investments), or through Real Estate Crowdfunding (micro-investments from multiple strategic partners). We manage, supervise, and execute every stage of the project, always.
        </p>

    </div>



</div>