<div class="container mt-5">
    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">What Do We Do?</h2>
        <p> <strong>We accompany, advise, and instruct</strong> our clients and strategic partners so they can channel their real estate investments individually, collectively (as a group), or through peer-to-peer real estate funding (micro-investments from several strategic partners), managing, supervising, and executing each stage of the project, always.</p>
    </div>
</div>