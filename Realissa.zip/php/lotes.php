<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Búsqueda y
            evaluación de lotes</h2>


        <p>
        <h4>Procesos de calidad y actores expertos en la construcción.</h4>
        <li>Reserva y Due Diligence del lote</li>
        <li>Supervisión e información</li>
        <li>Permisos y habilitaciones</li>
        <li>Construcción</li>
        <li>Decisión</li>
        <li>Venta de la propiedad</li>
        </p>
    </div>



</div>