<div class="container mt-5">
    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Disclaimer</h2>
        <h4>Descargo y aclaración de responsabilidad</h4>
        <p>Aquí presentamos proyecciones y declaraciones a futuro, que incluyen estimaciones sobre rendimiento financiero y operativo de construcción. Tales contenidos se basan en suposiciones y expectativas actuales sobre eventos futuros y tendencias que pueden afectar el proyecto y no deben ser considerados como hechos que efectivamente ocurrirán.</p>
        <br>
        <p>Tampoco son garantías del rendimiento futuro del proyecto. Se advierte a los inversores que dichas proyecciones y declaraciones a futuro están sujetas a riesgos, incertidumbres, contingencias y otros factores externos desconocidos, muchos de los cuales están fuera del control de constructores, Project Managers y comercializadores. Estos y otros factores pueden afectar las estimaciones y presupuestos en los que se basan.</p>
    </div>
</div>