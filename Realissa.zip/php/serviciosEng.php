<div class="container mt-5">


    <div class="col-md-7 mb-4 textoComponentes">
        <h2 class="mb-4">Services</h2>

        <p>
            Real Estate Crowdfunding: GROW AND WIN TOGETHER
            This is a model of collective financing where investment is consolidated through the cooperation of several investors to buy and/or build properties.
            In this model, the return on investment and project profitability will be realized at the time of the property's sale and will be distributed proportionally according to each investor's contribution.
            /INVESTMENT
            /LOT PURCHASE + CONSTRUCTION + SALE
            /INVESTMENT + PROFIT
        </p>

    </div>



</div>